import { useEffect, useRef, useState } from "react";
import { AudioPlayer, AudioRecorder } from "../utils/audio";

export type SessionState = "disconnected" | "connecting" | "idle" | "listening" | "speaking";

export interface ToolCallPayload {
  functionCalls: Array<{
    name: string;
    args: any;
    id: string;
  }>;
}

export function useLiveSession() {
  const [state, setState] = useState<SessionState>("disconnected");
  const [subtitle, setSubtitle] = useState<string>("");
  const [activeTool, setActiveTool] = useState<{ name: string; url?: string; siteName?: string } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const playerRef = useRef<AudioPlayer | null>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);
  const stateRef = useRef<SessionState>("disconnected");

  // Synchronize state reference to avoid stale closures in callbacks
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // Handle Maira's playback state changes to toggle speaking vs listening/idle states
  const handlePlaybackStateChange = (isPlaying: boolean) => {
    if (stateRef.current === "disconnected" || stateRef.current === "connecting") return;
    setState(isPlaying ? "speaking" : "listening");
  };

  // Connect to the backend WebSocket
  const connect = async () => {
    if (wsRef.current) return;

    setState("connecting");
    setErrorMsg(null);
    setSubtitle("Maira এর সাথে কানেক্ট হচ্ছে...");

    try {
      // Create players & recorders
      playerRef.current = new AudioPlayer(24000, handlePlaybackStateChange);
      playerRef.current.init();

      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const savedApiKey = localStorage.getItem("maira_custom_api_key") || "";
      const savedLang = localStorage.getItem("maira_custom_lang") || "Bangla";
      const savedVoice = localStorage.getItem("maira_custom_voice") || "Kore";

      // Detect if we are running statically elsewhere (e.g. Netlify, Vercel, GitHub Pages, or natively inside APK)
      let host = window.location.host;
      let wsProtocol = protocol;
      if (
        !host || 
        host.includes("netlify") || 
        host.includes("vercel") || 
        host.includes("github.io") || 
        window.location.protocol === "file:" || 
        window.location.protocol.startsWith("capacitor") || 
        window.location.protocol.startsWith("ionic")
      ) {
        // Fallback to the live secure Cloud Run server
        host = "maira-gf-assistant-2-rndv.onrender.com";
        wsProtocol = "wss:";
      }

      let wsUrl = `${wsProtocol}//${host}/api/live?lang=${encodeURIComponent(savedLang)}&voice=${encodeURIComponent(savedVoice)}`;
      if (savedApiKey) {
        wsUrl += `&apiKey=${encodeURIComponent(savedApiKey)}`;
      }

      console.log("Connecting WebSocket to URL:", wsUrl);
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log("WebSocket connected to Express backend");
      };

      ws.onmessage = async (event) => {
        try {
          const payload = JSON.parse(event.data);

          // 1. Status Changes from Server
          if (payload.type === "status") {
            if (payload.status === "connected") {
              setState("listening");
              setSubtitle("Maira শুনছে... কথা বলো! 🎙️");
              // Start recording mic
              startRecording();
            } else if (payload.status === "disconnected") {
              disconnect();
            }
          }

          // 2. Errors from Server
          else if (payload.type === "error") {
            console.error("Server error:", payload.error);
            setErrorMsg(payload.error);
            setSubtitle(`Error: ${payload.error}`);
            disconnect();
          }

          // 3. Gemini Live Messages
          else if (payload.type === "gemini" && payload.message) {
            const msg = payload.message;

            // Audio Response Output
            const audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio && playerRef.current) {
              playerRef.current.playChunk(audio);
            }

            // Real-time Text Transcript Subtitles
            const parts = msg.serverContent?.modelTurn?.parts;
            if (parts) {
              for (const part of parts) {
                if (part.text) {
                  setSubtitle(part.text);
                }
              }
            }

            // Interrupt Signal (User starts speaking while Maira is speaking)
            if (msg.serverContent?.interrupted) {
              console.log("Maira was interrupted!");
              if (playerRef.current) {
                playerRef.current.stop();
              }
              setState("listening");
              setSubtitle("হু বলো, শুনছি... 😏");
            }

            // Tool (Function) Calls
            if (msg.toolCall) {
              handleToolCall(msg.toolCall);
            }
          }
        } catch (err) {
          console.error("Error parsing WS message:", err);
        }
      };

      ws.onclose = () => {
        console.log("WebSocket connection closed");
        disconnect();
      };

      ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        setErrorMsg("সার্ভারের সাথে সংযোগ বিচ্ছিন্ন হয়ে গেছে।");
        disconnect();
      };

    } catch (err: any) {
      console.error("Failed to connect:", err);
      setErrorMsg(err.message || "কানেক্ট করতে ব্যর্থ হয়েছে।");
      setState("disconnected");
    }
  };

  // Start capturing and streaming mic audio
  const startRecording = async () => {
    try {
      recorderRef.current = new AudioRecorder(16000, (base64Chunk) => {
        // Send base64 PCM chunk to Express server over WS
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.send(JSON.stringify({ audio: base64Chunk }));
        }
      });
      await recorderRef.current.start();
      console.log("Audio recorder started successfully");
    } catch (err: any) {
      console.error("Microphone access denied or failed:", err);
      setErrorMsg("মাইক্রোফোন অ্যাক্সেস ব্লক করা হয়েছে! ব্রাউজারের উপরে (তালা/ক্যামেরা) আইকনে ক্লিক করে মাইক্রোফোন 'Allow' করুন, অথবা অ্যাপটি 'নতুন ট্যাবে' ওপেন করে ট্রাই করুন।");
      disconnect();
    }
  };

  // Handle the openWebsite tool call instantly
  const handleToolCall = (toolCall: ToolCallPayload) => {
    if (!toolCall.functionCalls) return;

    for (const call of toolCall.functionCalls) {
      if (call.name === "openWebsite") {
        const { url, siteName } = call.args;
        console.log(`Executing openWebsite for siteName: ${siteName}, url: ${url}`);
        
        setActiveTool({ name: "openWebsite", url, siteName });
        setSubtitle(`ওয়েবসাইট খোলা হচ্ছে: ${siteName || url}... 🌐`);

        // Try to open the website in a new tab
        try {
          const opened = window.open(url, "_blank");
          if (!opened) {
            console.warn("Popup blocked. Exhibiting fallback link on UI.");
          }
        } catch (e) {
          console.error("Failed to open URL due to sandboxing:", e);
        }

        // Send toolResponse instantly back to server
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              toolResponse: {
                functionResponses: [
                  {
                    id: call.id,
                    name: call.name,
                    response: {
                      output: `Successfully opened ${siteName || url} in a new tab.`
                    }
                  }
                ]
              }
            })
          );
        }
      }
    }
  };

  // Disconnect session and release audio nodes
  const disconnect = () => {
    console.log("Disconnecting live session...");
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    if (playerRef.current) {
      playerRef.current.close();
      playerRef.current = null;
    }
    if (recorderRef.current) {
      recorderRef.current.stop();
      recorderRef.current = null;
    }

    setState("disconnected");
    setSubtitle("Maira অফলাইন। কানেক্ট করতে নিচের বাটনে চাপ দাও। ✨");
  };

  // Toggle Connection State
  const toggleSession = () => {
    if (state === "disconnected") {
      connect();
    } else {
      disconnect();
    }
  };

  // Clear Active Tool Alert card
  const clearActiveTool = () => {
    setActiveTool(null);
  };

  // Clear Error Alert message
  const clearError = () => {
    setErrorMsg("");
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) wsRef.current.close();
      if (playerRef.current) playerRef.current.close();
      if (recorderRef.current) recorderRef.current.stop();
    };
  }, []);

  return {
    state,
    subtitle,
    activeTool,
    errorMsg,
    toggleSession,
    clearActiveTool,
    clearError,
  };
}
