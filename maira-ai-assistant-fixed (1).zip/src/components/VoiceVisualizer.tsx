import React from "react";
import { motion } from "motion/react";
import { SessionState } from "../hooks/useLiveSession";

interface VoiceVisualizerProps {
  state: SessionState;
  onToggle?: () => void;
}

// 23 nodes strategically distributed in a spherical pattern to match the screenshot's neural core
const NEURAL_NODES = [
  { x: 50, y: 15 }, { x: 32, y: 26 }, { x: 68, y: 26 },
  { x: 18, y: 45 }, { x: 50, y: 48 }, { x: 82, y: 45 },
  { x: 26, y: 70 }, { x: 74, y: 70 }, { x: 50, y: 85 },
  { x: 40, y: 22 }, { x: 60, y: 22 }, { x: 24, y: 35 },
  { x: 76, y: 35 }, { x: 34, y: 56 }, { x: 66, y: 56 },
  { x: 42, y: 36 }, { x: 58, y: 36 }, { x: 42, y: 62 },
  { x: 58, y: 62 }, { x: 31, y: 46 }, { x: 69, y: 46 },
  { x: 38, y: 76 }, { x: 62, y: 76 }
];

// Dynamically generate wireframe connections between nearby nodes
const NEURAL_CONNECTIONS: [number, number][] = [];
for (let i = 0; i < NEURAL_NODES.length; i++) {
  for (let j = i + 1; j < NEURAL_NODES.length; j++) {
    const dist = Math.hypot(
      NEURAL_NODES[i].x - NEURAL_NODES[j].x,
      NEURAL_NODES[i].y - NEURAL_NODES[j].y
    );
    // Connect nodes that are relatively close to form an organic wireframe plexus
    if (dist < 22) {
      NEURAL_CONNECTIONS.push([i, j]);
    }
  }
}

export default function VoiceVisualizer({ state, onToggle }: VoiceVisualizerProps) {
  
  // Define dynamic holographic orbit and neural styles based on session state
  const getVisualConfig = () => {
    switch (state) {
      case "connecting":
        return {
          glowColor: "rgba(139, 92, 246, 0.4)", // Violet
          coreGlow: "shadow-[0_0_50px_15px_rgba(139,92,246,0.3)]",
          orbitGold: "border-amber-500/30",
          orbitCrimson: "border-violet-600/40",
          neuralColor: "#a78bfa", // Violet-400
          pulseScale: [1, 1.03, 1],
          pulseDuration: 1.5,
          statusText: "SYNCING CORE...",
          statusColor: "text-violet-400",
        };
      case "listening":
        return {
          glowColor: "rgba(244, 63, 94, 0.4)", // Crimson
          coreGlow: "shadow-[0_0_70px_20px_rgba(244,63,94,0.35)]",
          orbitGold: "border-amber-400/50",
          orbitCrimson: "border-rose-600/60 shadow-[0_0_15px_rgba(244,63,94,0.3)]",
          neuralColor: "#fda4af", // Rose-300
          pulseScale: [1, 1.06, 0.98, 1],
          pulseDuration: 2.0,
          statusText: "LISTENING...",
          statusColor: "text-rose-400 animate-pulse",
        };
      case "speaking":
        return {
          glowColor: "rgba(20, 184, 166, 0.45)", // Teal
          coreGlow: "shadow-[0_0_80px_25px_rgba(20,184,166,0.4)]",
          orbitGold: "border-teal-400/60 shadow-[0_0_20px_rgba(20,184,166,0.2)]",
          orbitCrimson: "border-cyan-600/50",
          neuralColor: "#5eead4", // Teal-300
          pulseScale: [1, 1.1, 0.96, 1.05, 1],
          pulseDuration: 0.8, // Rapid pulse matching speech
          statusText: "PROCESSING...",
          statusColor: "text-teal-300",
        };
      case "idle":
        return {
          glowColor: "rgba(245, 158, 11, 0.25)", // Amber/Orange
          coreGlow: "shadow-[0_0_40px_12px_rgba(245,158,11,0.2)]",
          orbitGold: "border-amber-500/40",
          orbitCrimson: "border-amber-800/20",
          neuralColor: "#fcd34d", // Amber-300
          pulseScale: [1, 1.04, 1],
          pulseDuration: 3.0, // Slow breathing
          statusText: "IDLE CORE",
          statusColor: "text-amber-500",
        };
      case "disconnected":
      default:
        return {
          glowColor: "rgba(107, 114, 128, 0.1)", // Gray
          coreGlow: "shadow-none",
          orbitGold: "border-zinc-800/30",
          orbitCrimson: "border-zinc-900/40",
          neuralColor: "#71717a", // Zinc-400
          pulseScale: 1,
          pulseDuration: 4.0,
          statusText: "OFFLINE",
          statusColor: "text-zinc-500",
        };
    }
  };

  const config = getVisualConfig();

  return (
    <div id="visualizer-container" className="relative flex items-center justify-center w-80 h-80 md:w-[400px] md:h-[400px]">
      
      {/* 3D Holographic Orbiting Rings (Styled precisely to match the user's uploaded screenshot) */}
      <div id="holographic-orbits" className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 select-none">
        
        {/* Screenshot Core Feature: Thick Glowing Red Sweeper Orbit Ring */}
        <motion.div
          id="orbit-crimson-ring"
          className={`absolute w-72 h-72 md:w-88 md:h-88 rounded-full border-2 ${config.orbitCrimson} transition-colors duration-700`}
          style={{ rotateX: 62, rotateY: 32, rotateZ: 0 }}
          animate={{ rotateZ: 360 }}
          transition={{ repeat: Infinity, duration: 12, ease: "linear" }}
        >
          {/* Glowing Red Orbit Particle */}
          <div className="absolute top-0 left-1/2 -ml-1.5 w-3 h-3 bg-red-500 rounded-full shadow-[0_0_12px_#ef4444]" />
        </motion.div>

        {/* Screenshot Core Feature: Thin Glowing Gold/Orange Orbit Ring */}
        <motion.div
          id="orbit-gold-ring"
          className={`absolute w-60 h-60 md:w-[290px] md:h-[290px] rounded-full border ${config.orbitGold} transition-colors duration-700`}
          style={{ rotateX: 72, rotateY: -18, rotateZ: 0 }}
          animate={{ rotateZ: -360 }}
          transition={{ repeat: Infinity, duration: 16, ease: "linear" }}
        >
          {/* Glowing Amber Orbit Particle */}
          <div className="absolute bottom-0 left-1/2 -ml-1 w-2.5 h-2.5 bg-amber-400 rounded-full shadow-[0_0_10px_#fbbf24]" />
        </motion.div>

        {/* Screenshot Feature: Fine outer concentric border rings */}
        <div className="absolute w-[310px] h-[310px] md:w-[370px] md:h-[370px] rounded-full border border-red-950/20" style={{ rotateX: 75 }} />
        <div className="absolute w-[320px] h-[320px] md:w-[380px] md:h-[380px] rounded-full border border-dashed border-red-900/10" style={{ rotateX: 75 }} />
      </div>

      {/* Outer Ripple Effects (only during active state) */}
      {state === "listening" && (
        <motion.div
          className="absolute w-72 h-72 rounded-full bg-red-500/5 border border-red-500/20"
          initial={{ scale: 0.9, opacity: 0.8 }}
          animate={{ scale: 1.4, opacity: 0 }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeOut" }}
        />
      )}

      {/* Central Neural Plexus Orb Container */}
      <motion.div
        id="neural-plexus-orb"
        onClick={onToggle}
        className={`relative w-52 h-52 md:w-64 md:h-64 rounded-full bg-black/40 border border-zinc-900 ${config.coreGlow} flex items-center justify-center transition-all duration-300 z-10 overflow-hidden cursor-pointer hover:border-red-500/30 active:scale-[0.98]`}
        animate={{ scale: config.pulseScale }}
        transition={{ repeat: Infinity, duration: config.pulseDuration, ease: "easeInOut" }}
      >
        {/* Holographic Radial Gradient inside core */}
        <div 
          className="absolute inset-0 opacity-20 pointer-events-none transition-all duration-700" 
          style={{
            background: `radial-gradient(circle, ${config.glowColor} 0%, transparent 70%)`
          }}
        />

        {/* Golden Neural Net Wireframe Graph (Renders exactly like the wireframe plexus in screenshot) */}
        <svg 
          id="neural-net-svg" 
          className="absolute inset-0 w-full h-full p-4 pointer-events-none" 
          viewBox="0 0 100 100"
        >
          {/* Draw Connection Links */}
          {NEURAL_CONNECTIONS.map(([idx1, idx2], i) => {
            const p1 = NEURAL_NODES[idx1];
            const p2 = NEURAL_NODES[idx2];
            return (
              <motion.line
                key={`link-${i}`}
                x1={p1.x}
                y1={p1.y}
                x2={p2.x}
                y2={p2.y}
                stroke={config.neuralColor}
                strokeWidth={state === "disconnected" ? "0.15" : "0.35"}
                initial={{ opacity: 0.1 }}
                animate={{ 
                  opacity: state === "disconnected" ? 0.15 : [0.25, 0.5, 0.25],
                  strokeWidth: state === "speaking" ? [0.35, 0.6, 0.35] : 0.35
                }}
                transition={{
                  repeat: Infinity,
                  duration: 2 + (i % 3),
                  ease: "easeInOut",
                }}
              />
            );
          })}

          {/* Draw Synaptic Nodes */}
          {NEURAL_NODES.map((node, i) => (
            <motion.circle
              key={`node-${i}`}
              cx={node.x}
              cy={node.y}
              r={state === "disconnected" ? "0.6" : "1.0"}
              fill={config.neuralColor}
              initial={{ opacity: 0.3 }}
              animate={{
                r: state === "speaking" ? [1.0, 1.6, 1.0] : 1.0,
                opacity: state === "disconnected" ? 0.3 : [0.4, 0.9, 0.4]
              }}
              transition={{
                repeat: Infinity,
                duration: 1.5 + (i % 4) * 0.5,
                ease: "easeInOut",
              }}
              style={{
                filter: state !== "disconnected" ? "drop-shadow(0px 0px 1.5px rgba(245, 158, 11, 0.6))" : "none"
              }}
            />
          ))}
        </svg>

        {/* Central Core Text: Brand and Neural Stats (Matches Screenshot perfectly, with name 'MaiRa') */}
        <div className="absolute flex flex-col items-center justify-center text-center z-20 pointer-events-none select-none">
          {/* 'MaiRa' written in futuristic capitalized tracked sci-fi branding */}
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-[0.18em] text-white font-mono drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
            MAIRA
          </h2>
          
          {/* 'NEURAL CORE' text inside plexus */}
          <span className="text-[8px] md:text-[9px] font-bold tracking-[0.3em] text-amber-500/80 uppercase mt-0.5">
            NEURAL CORE
          </span>

          {/* Live system state text from screenshot (e.g. PROCESSING, LISTENING, etc) */}
          <span className={`text-[7px] md:text-[8px] font-semibold tracking-[0.2em] uppercase mt-2.5 px-2 py-0.5 rounded-sm bg-black/40 border border-zinc-900 ${config.statusColor}`}>
            {config.statusText}
          </span>
        </div>

      </motion.div>
    </div>
  );
}
