import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  AlertCircle, ExternalLink, Sparkles, HelpCircle, Heart, X, Home, Settings, 
  Sliders, Volume2, ShieldCheck, Eye, EyeOff, Languages, KeyRound, Shield, CheckCircle 
} from "lucide-react";
import { useLiveSession } from "./hooks/useLiveSession";
import VoiceVisualizer from "./components/VoiceVisualizer";

const mairaAvatar = "/src/assets/images/maira_avatar_1788706481278.jpg";

// Sassy Bengali quotes of MaiRa to highlight her personality on screen
const MAIRA_QUOTES = [
  "তোমাকে তো বেশ মিষ্টি দেখাচ্ছে আজ! 💖",
  "একটু কথা বলেই দেখো, প্রেমে পড়ে যাবে! 😉",
  "আমি কিন্তু খুব সোজাসুজি কথা বলি, সামলাতে পারবে তো? 😏",
  "সব প্রশ্নের উত্তর কি এমনি এমনি পাওয়া যায়? আগে বলো কেমন আছো! 💅",
  "আজকে কি কোনো বিশেষ কারণে আমার কাছে এলে? ☕",
  "আমার ভয়েস শুনে মন ভালো হয়ে গেল না? স্বীকার করো! 😇",
  "বেশি পকপক কোরো না, MaiRa কিন্তু সব বুঝতে পারে! 🤫",
  "বাংলায় কথা বলো, ইংরেজি বেশি মারিও না বাপু! 😜",
  "উফফ, তোমার গলার আওয়াজটা তো বেশ আকর্ষণীয়! 🎵",
  "বলো কি শুনবে, তবে MaiRa-র মন মেজাজ ভালো থাকতে হবে কিন্তু! 🦁"
];

// List of language options with country codes for automatic locale detection
const LANGUAGE_OPTIONS = [
  { code: "Bangla", name: "Bengali / Bangladesh 🇧🇩", langCode: "bn", region: "Bangladesh" },
  { code: "English", name: "English / United States 🇺🇸", langCode: "en", region: "United States" },
  { code: "Spanish", name: "Spanish / Spain 🇪🇸", langCode: "es", region: "Spain" },
  { code: "Hindi", name: "Hindi / India 🇮🇳", langCode: "hi", region: "India" },
  { code: "Arabic", name: "Arabic / Saudi Arabia 🇸🇦", langCode: "ar", region: "Saudi Arabia" },
  { code: "Japanese", name: "Japanese / Japan 🇯🇵", langCode: "ja", region: "Japan" },
  { code: "German", name: "German / Germany 🇩🇪", langCode: "de", region: "Germany" },
];

// The complete system permissions requested by the user
const PERMISSION_ITEMS = [
  // Original requested permissions
  { id: "calls", label: "Calls & SMS", category: "Communication", desc: "Allows MaiRa to draft messages and schedule phone calls" },
  { id: "whatsapp", label: "WhatsApp", category: "Communication", desc: "Enables WhatsApp messenger chat and contact lookup" },
  { id: "music", label: "Music & Video", category: "Entertainment", desc: "Access media playback, Spotify streams, and YouTube control" },
  { id: "phone", label: "Phone control", category: "System Core", desc: "Reads device states (battery, system volumes, silence mode)" },
  { id: "screen", label: "Screen & camera", category: "Hardware", desc: "Allows screen capturing and computer vision assistance" },
  { id: "alarms", label: "Alarms & reminders", category: "Scheduler", desc: "Enables creating timers and voice alarms" },
  { id: "notifications", label: "Notifications", category: "Alerts", desc: "Pushes system notifications and passive alerts" },
  { id: "files", label: "Files & docs", category: "Storage", desc: "Reads uploaded document text, PDFs, and spreadsheets" },
  { id: "coding", label: "Coding & websites", category: "Developer", desc: "Enables rendering sandbox preview code frames" },
  { id: "knowledge", label: "Knowledge & live info", category: "Grounding", desc: "Grants access to Google Search grounding integration" },
  { id: "location", label: "Location & maps", category: "Grounding", desc: "Accesses coordinates for local weather and nearby reviews" },
  { id: "smarthome", label: "Smart home", category: "IoT", desc: "Controls home automation networks, lights, and thermostats" },
  { id: "memory", label: "Memory", category: "Cognitive", desc: "Saves details you share into a persistent context profile" },
  { id: "study", label: "Study mode", category: "Cognitive", desc: "Increases structural learning modules and math grounding" },
  { id: "macros", label: "Task macros", category: "Automation", desc: "Combines multiple tool instructions into sequence macros" },
  { id: "personas", label: "Personas & voice", category: "Aesthetics", desc: "Customizes voice parameters, pitch, and sass quotient" },
  { id: "system", label: "System & settings", category: "System Core", desc: "Grants terminal script execution and system modifications" },

  // New additions requested by the user
  { id: "microphone", label: "Microphone", category: "Hardware", desc: "PCM 16kHz voice capture for active voice sessions" },
  { id: "camera_hardware", label: "Camera", category: "Hardware", desc: "Real-time image capture and live object recognition" },
  { id: "phone_calls_native", label: "Phone calls", category: "Communication", desc: "Initiate telephone calls from voice instructions" },
  { id: "contact", label: "Contact", category: "Communication", desc: "Lookup friends and family contact numbers" },
  { id: "sms_native", label: "SMS", category: "Communication", desc: "Send, receive, and parse incoming text messages" },
  { id: "gallery_files", label: "Gallery & files", category: "Storage", desc: "Examine photos, system downloads, and local media folders" },
  { id: "answer_manage_calls", label: "Answer & manage Call's", category: "Communication", desc: "Receive, accept, end, and toggle telephony audio routing" },
  { id: "bluetooth", label: "Bluetooth", category: "Hardware", desc: "Scan, pair, and stream audio to companion headset peripherals" },
  { id: "app_notifications", label: "App Notifications", category: "Alerts", desc: "Pushes custom status banners and live session status alerts" },
  { id: "notification_access", label: "Notification access", category: "Alerts", desc: "Read and reply to notification logs from other installed apps" },
  { id: "accessibility_service", label: "Accessibility service", category: "System Core", desc: "Perform automated touch gestures and scroll actions on the display" },
  { id: "battery_no_opt", label: "Battery No Optimization", category: "System Core", desc: "Exempt app from background battery limits for continuous connectivity" },
  { id: "display_over_other", label: "Display over Other app", category: "Overlay UI", desc: "Draw floating overlays and interactive bubbles over active tasks" },
  { id: "screen_capture", label: "Screen Capture", category: "Overlay UI", desc: "Stream your current screen to Gemini visual intelligence for assistance" },
  { id: "eco_guard", label: "ECO Guard", category: "System Core", desc: "Monitors app idle states to optimize CPU power and hardware temperature" }
];

export default function App() {
  const {
    state,
    subtitle,
    activeTool,
    errorMsg,
    toggleSession,
    clearActiveTool,
    clearError,
  } = useLiveSession();

  const [quoteIndex, setQuoteIndex] = useState(0);
  const [showInfo, setShowInfo] = useState(false);
  
  // Navigation State: "home" | "setting"
  const [activeTab, setActiveTab] = useState<"home" | "setting">("home");

  // Setting Sub-sections for clean separation
  const [activeSettingsPanel, setActiveSettingsPanel] = useState<"api" | "lang" | "perms">("api");

  // API Key States (Secure Masked Input)
  // Users can optionally paste their own Gemini API key here in Settings.
  // Nothing is hardcoded — if left empty, the app uses the server's own configured key.
  const [apiKeyInput, setApiKeyInput] = useState(() => {
    return localStorage.getItem("maira_custom_api_key") || "";
  });
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKeySaved, setApiKeySaved] = useState(true);

  // Language Selection and Geo-detection states
  const [selectedLang, setSelectedLang] = useState(() => {
    return localStorage.getItem("maira_custom_lang") || "Bangla";
  });
  const [detectedLocationMsg, setDetectedLocationMsg] = useState("");

  // 31 Permissions State Dictionary (Merged dynamically with browser cache so new entries show instantly)
  const [permissions, setPermissions] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    PERMISSION_ITEMS.forEach(item => {
      initial[item.id] = false;
    });

    const saved = localStorage.getItem("maira_custom_permissions");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...initial, ...parsed };
      } catch (e) {}
    }
    return initial;
  });

  // Auto-detect browser location locale and select recommended country language
  useEffect(() => {
    const locale = navigator.language || "en-US";
    const matched = LANGUAGE_OPTIONS.find(opt => locale.toLowerCase().startsWith(opt.langCode));
    const suggestedLang = matched ? matched.code : "Bangla";

    if (!localStorage.getItem("maira_custom_lang")) {
      setSelectedLang(suggestedLang);
      localStorage.setItem("maira_custom_lang", suggestedLang);
      setDetectedLocationMsg(`Detected device locale (${locale}). Auto-selected: ${matched?.name || suggestedLang}`);
    } else {
      const active = localStorage.getItem("maira_custom_lang") || "Bangla";
      const activeName = LANGUAGE_OPTIONS.find(o => o.code === active)?.name || active;
      setDetectedLocationMsg(`Device locale (${locale}) matches. Active core: ${activeName}`);
    }
  }, []);

  // Rotate MaiRa's sassy quotes every 7 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setQuoteIndex((prev) => (prev + 1) % MAIRA_QUOTES.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const handleLanguageChange = (langCodeName: string) => {
    setSelectedLang(langCodeName);
    localStorage.setItem("maira_custom_lang", langCodeName);
  };

  const handleSaveApiKey = () => {
    localStorage.setItem("maira_custom_api_key", apiKeyInput);
    setApiKeySaved(true);
    setTimeout(() => setApiKeySaved(false), 2500);
  };

  const handleClearApiKey = () => {
    setApiKeyInput("");
    localStorage.removeItem("maira_custom_api_key");
  };

  const handleTogglePermission = (id: string) => {
    setPermissions(prev => {
      const updated = { ...prev, [id]: !prev[id] };
      localStorage.setItem("maira_custom_permissions", JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <div id="main-container" className="min-h-screen bg-[#020306] text-zinc-100 flex flex-col justify-between items-center px-4 py-6 md:py-8 overflow-hidden relative font-sans select-none">
      
      {/* Background Ambient Glowing Elements (Red/Crimson tones to match screenshot) */}
      <div id="glow-circle-1" className="absolute -top-40 -left-40 w-96 h-96 bg-red-950/20 rounded-full blur-[120px] pointer-events-none" />
      <div id="glow-circle-2" className="absolute -bottom-40 -right-40 w-96 h-96 bg-red-900/15 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Navbar */}
      <header id="app-header" className="w-full max-w-lg flex justify-between items-center z-20">
        <div id="logo-wrapper" className="flex items-center gap-2">
          <div className="relative w-10 h-10 rounded-full border border-red-500/30 overflow-hidden shadow-[0_0_15px_rgba(239,68,68,0.25)] flex items-center justify-center bg-zinc-950">
            <img
              src={mairaAvatar}
              alt="MaiRa AI"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-[0.08em] bg-gradient-to-r from-red-400 via-amber-300 to-red-400 bg-clip-text text-transparent font-mono uppercase">
              MaiRa
            </h1>
            <p className="text-[9px] text-red-500/80 font-mono tracking-widest uppercase">DEVELOPED BY MAMUN</p>
          </div>
        </div>

        <div id="header-actions" className="flex items-center gap-3">
          {/* Status Indicator Pill */}
          <button
            onClick={toggleSession}
            title="ক্লিক করে অন/অফ করুন"
            className="flex items-center gap-1.5 bg-zinc-950/80 hover:bg-zinc-900 border border-zinc-900 hover:border-red-500/20 px-2.5 py-1 rounded-full text-xs transition-all cursor-pointer"
          >
            <span className={`w-2.5 h-2.5 rounded-full ${
              state === "disconnected" ? "bg-zinc-600" :
              state === "connecting" ? "bg-violet-500 animate-ping" :
              state === "listening" ? "bg-red-500 animate-pulse" :
              "bg-amber-400 animate-pulse"
            }`} />
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
              {state === "disconnected" ? "OFFLINE" : state}
            </span>
          </button>

          {/* Info Toggle Button */}
          <button
            id="info-toggle-btn"
            onClick={() => setShowInfo(!showInfo)}
            className="p-1.5 rounded-full bg-zinc-950/80 border border-zinc-900 text-zinc-500 hover:text-red-400 hover:border-red-500/30 transition-all cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Interactive Stage - Content changes depending on active tab */}
      <main id="app-stage" className="flex-1 flex flex-col justify-center items-center w-full max-w-lg z-10 py-4">
        
        <AnimatePresence mode="wait">
          {activeTab === "home" ? (
            <motion.div
              key="home-view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="w-full flex flex-col items-center justify-center"
            >
              {/* Animated Subtitle / Live Transcript Display */}
              <div id="subtitle-card" className="w-full min-h-[96px] max-h-[140px] flex items-center justify-center bg-zinc-950/30 border border-red-950/40 backdrop-blur-md rounded-2xl p-5 mb-8 shadow-[inset_0_1px_1px_rgba(255,255,255,0.02)] text-center overflow-y-auto">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={subtitle || "empty"}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.25 }}
                    className={`text-[14px] md:text-[15px] leading-relaxed font-medium ${
                      state === "disconnected" ? "text-zinc-500 italic" :
                      state === "speaking" ? "text-amber-200" :
                      state === "listening" ? "text-red-300" : "text-zinc-300"
                    }`}
                  >
                    {subtitle || "MaiRa অফলাইন। কথা বলতে মাঝের কোরে (Core) টাচ করো! ✨"}
                  </motion.p>
                </AnimatePresence>
              </div>

              {/* Core Voice Animation Orb */}
              <VoiceVisualizer state={state} onToggle={toggleSession} />


            </motion.div>
          ) : (
            // Extended Settings Panel View
            <motion.div
              key="settings-view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="w-full bg-zinc-950/40 border border-zinc-900 backdrop-blur-md rounded-2xl p-4 md:p-5 space-y-4"
            >
              {/* Header Title */}
              <div className="border-b border-zinc-900 pb-2">
                <h3 className="text-sm font-bold tracking-[0.15em] text-red-400 font-mono uppercase flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-red-500" /> System Control Panel
                </h3>
                <p className="text-[9px] text-zinc-500 mt-0.5 font-mono uppercase tracking-wider">Configure shell languages, security keys, and systems</p>
              </div>

              {/* Collapsible Tabs inside Settings */}
              <div className="grid grid-cols-3 gap-1 bg-zinc-950/60 p-1 border border-zinc-900 rounded-lg">
                <button
                  onClick={() => setActiveSettingsPanel("api")}
                  className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded transition-all cursor-pointer ${
                    activeSettingsPanel === "api" ? "bg-red-950/40 text-red-400 border border-red-950" : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  Key Config
                </button>
                <button
                  onClick={() => setActiveSettingsPanel("lang")}
                  className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded transition-all cursor-pointer ${
                    activeSettingsPanel === "lang" ? "bg-red-950/40 text-red-400 border border-red-950" : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  Languages
                </button>
                <button
                  onClick={() => setActiveSettingsPanel("perms")}
                  className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded transition-all cursor-pointer ${
                    activeSettingsPanel === "perms" ? "bg-red-950/40 text-red-400 border border-red-950" : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  Perms ({PERMISSION_ITEMS.length})
                </button>
              </div>

              {/* Sub-Panel 1: API Key Config */}
              {activeSettingsPanel === "api" && (
                <div className="space-y-3.5 animate-fadeIn">
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                      <KeyRound className="w-4 h-4 text-red-500" /> Live Gemini API Key
                    </h4>
                    <p className="text-[10px] text-zinc-500 leading-normal">
                      আপনার নিজস্ব API কী বসান। এটি বসানোর পরে নিরাপদভাবে সুরক্ষিত ও হিডেন থাকবে (Masked)।
                    </p>
                  </div>

                  {/* Input field with eye icon */}
                  <div className="relative">
                    <input
                      type={showApiKey ? "text" : "password"}
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      placeholder="Enter AI Studio API Key..."
                      className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-4 py-2.5 text-xs text-zinc-300 font-mono pr-12 focus:outline-none focus:border-red-500/50"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 cursor-pointer"
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Save/Clear buttons */}
                  <div className="flex gap-2">
                    <button
                      onClick={handleSaveApiKey}
                      className="flex-1 py-2 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-semibold rounded-lg text-[10px] uppercase font-mono tracking-wider shadow-md hover:shadow-red-500/10 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      {apiKeySaved ? (
                        <>
                          <CheckCircle className="w-3.5 h-3.5" /> SECURED KEY
                        </>
                      ) : (
                        "SAVE CONFIG MATRIX"
                      )}
                    </button>
                    {localStorage.getItem("maira_custom_api_key") && (
                      <button
                        onClick={handleClearApiKey}
                        className="py-2 px-3 bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 hover:border-zinc-700 text-zinc-400 rounded-lg text-[10px] font-mono cursor-pointer"
                      >
                        RESET
                      </button>
                    )}
                  </div>

                  {/* Masked status indicator */}
                  {localStorage.getItem("maira_custom_api_key") && (
                    <div className="bg-zinc-950/60 border border-dashed border-red-950/40 rounded-xl p-3 text-[10px] text-red-400/80 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-red-500" />
                      <span>
                        সিস্টেম সিকিউরড: আপনার সংরক্ষিত কী এখন সক্রিয়। (`••••••••••••••••`)
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Sub-Panel 2: Country Languages list & geo detection */}
              {activeSettingsPanel === "lang" && (
                <div className="space-y-3 animate-fadeIn">
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                      <Languages className="w-4 h-4 text-red-500" /> Language & Locale Configuration
                    </h4>
                    <p className="text-[10px] text-zinc-500 leading-normal">
                      বিভিন্ন দেশের ভাষা তালিকা নিচে দেওয়া হলো। আপনার ফোনের লোকেশন locale-এর সাথে মিলিয়ে ভাষা স্বয়ংক্রিয়ভাবে রেকমেন্ড করা হয়েছে।
                    </p>
                  </div>

                  {/* Geolocation status message banner */}
                  <div className="bg-zinc-950 border border-zinc-900 p-2.5 rounded-xl text-[9px] font-mono text-zinc-400 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>{detectedLocationMsg}</span>
                  </div>

                  {/* Grid list of selectable countries' languages with professional neuromorphic UI modeling */}
                  <div className="space-y-2 max-h-[30vh] overflow-y-auto pr-1">
                    {LANGUAGE_OPTIONS.map((opt) => {
                      const isActive = selectedLang === opt.code;
                      return (
                        <button
                          key={opt.code}
                          onClick={() => handleLanguageChange(opt.code)}
                          className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-xs transition-all duration-300 text-left cursor-pointer relative overflow-hidden ${
                            isActive
                              ? "bg-gradient-to-r from-red-950/30 to-amber-950/15 border-red-500/50 text-red-200 shadow-[0_0_15px_rgba(239,68,68,0.1)]"
                              : "bg-zinc-950/50 border-zinc-900/80 text-zinc-400 hover:bg-zinc-900/80 hover:border-zinc-800 hover:text-zinc-200"
                          } active:scale-[0.985]`}
                        >
                          {/* Inner glowing effect on active */}
                          {isActive && (
                            <div className="absolute inset-0 bg-radial-gradient from-red-500/5 to-transparent pointer-events-none" />
                          )}

                          <div className="flex items-center gap-3.5 z-10">
                            {/* Premium glowing radio button circle */}
                            <div className={`w-4 h-4 rounded-full border flex items-center justify-center transition-all duration-300 ${
                              isActive ? "border-red-500 bg-red-950/40" : "border-zinc-800 bg-zinc-950"
                            }`}>
                              {isActive && (
                                <motion.div
                                  layoutId="activeRadioDot"
                                  className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"
                                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                                />
                              )}
                            </div>

                            {/* Label & Description */}
                            <div className="flex flex-col">
                              <span className={`font-mono text-[11px] uppercase tracking-wider ${isActive ? "text-red-300 font-bold" : "text-zinc-300"}`}>
                                {opt.name.split(" / ")[0]}
                              </span>
                              <span className="text-[9px] text-zinc-500 font-sans mt-0.5">
                                Region: {opt.region}
                              </span>
                            </div>
                          </div>

                          {/* Country Code Pill on the right */}
                          <div className="z-10">
                            <span className={`text-[8.5px] font-mono font-bold tracking-widest uppercase px-2 py-0.5 rounded-md border ${
                              isActive
                                ? "bg-red-950/40 border-red-500/30 text-red-400"
                                : "bg-zinc-950 border-zinc-900 text-zinc-600"
                            }`}>
                              {opt.langCode}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Sub-Panel 3: The 17 Core System Permissions toggles */}
              {activeSettingsPanel === "perms" && (
                <div className="space-y-3 animate-fadeIn">
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-red-500" /> Neuromorphic System Permissions
                    </h4>
                    <p className="text-[10px] text-zinc-500 leading-normal">
                      MaiRa কোরের জন্য নিচের প্রয়োজনীয় সিস্টেম পারমিশনগুলো অন/অফ করুন।
                    </p>
                  </div>

                  {/* Scrollable list of all 31 permission items */}
                  <div className="space-y-1.5 max-h-[50vh] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-red-950">
                    {PERMISSION_ITEMS.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between bg-zinc-950/40 border border-zinc-900/80 p-2.5 rounded-xl text-left gap-3 hover:border-zinc-800 transition-colors"
                      >
                        <div className="space-y-0.5 flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-bold text-zinc-300 truncate">
                              {item.label}
                            </span>
                            {item.category && (
                              <span className="text-[7px] font-mono tracking-wider uppercase bg-zinc-900 text-zinc-500 border border-zinc-800 px-1.5 py-0.2 rounded-sm">
                                {item.category}
                              </span>
                            )}
                          </div>
                          {item.desc && (
                            <p className="text-[8px] text-zinc-500 leading-normal truncate-2-lines">
                              {item.desc}
                            </p>
                          )}
                        </div>

                        {/* Slide Toggle Switch */}
                        <button
                          onClick={() => handleTogglePermission(item.id)}
                          className={`w-9 h-5 rounded-full p-0.5 transition-all duration-300 relative cursor-pointer ${
                            permissions[item.id] ? "bg-red-600 shadow-[0_0_8px_rgba(239,68,68,0.25)]" : "bg-zinc-850"
                          }`}
                        >
                          <div className={`bg-black w-4 h-4 rounded-full shadow-md transform duration-300 ${
                            permissions[item.id] ? "translate-x-4" : "translate-x-0"
                          }`} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* Tool Execution Alert / Redirection Card */}
      <AnimatePresence>
        {activeTool && (
          <motion.div
            id="tool-alert-overlay"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="absolute inset-x-4 top-1/3 md:top-1/4 max-w-md mx-auto bg-zinc-950 border border-red-500/30 rounded-2xl p-6 shadow-[0_15px_30px_rgba(0,0,0,0.8),0_0_30px_rgba(239,68,68,0.15)] z-40 text-center"
          >
            <div className="flex justify-between items-center mb-3">
              <span className="flex items-center gap-1.5 text-xs text-red-400 font-mono font-semibold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 animate-spin" /> Tool Execution
              </span>
              <button onClick={clearActiveTool} className="p-1 rounded-full text-zinc-500 hover:text-white hover:bg-zinc-900">
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <h3 className="text-lg font-bold text-zinc-100 mb-1">
              ওয়েবসাইট খোলা হচ্ছে!
            </h3>
            <p className="text-sm text-zinc-400 mb-5 leading-relaxed">
              MaiRa আপনার জন্য <span className="text-red-300 font-semibold">{activeTool.siteName || activeTool.url}</span> নতুন ট্যাবে খোলার চেষ্টা করছে।
            </p>

            <div className="flex flex-col gap-2">
              <a
                href={activeTool.url}
                target="_blank"
                rel="noreferrer"
                onClick={clearActiveTool}
                className="w-full py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2 shadow-[0_4px_12px_rgba(239,68,68,0.25)] transition-all cursor-pointer text-sm font-medium"
              >
                ওয়েবসাইটে সরাসরি যাও <ExternalLink className="w-4 h-4" />
              </a>
              <button
                onClick={clearActiveTool}
                className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs transition-all cursor-pointer font-mono"
              >
                CLOSE PANEL
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Info Card Drawer overlay */}
      <AnimatePresence>
        {showInfo && (
          <motion.div
            id="info-card-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50"
            onClick={() => setShowInfo(false)}
          >
            <motion.div
              id="info-modal"
              initial={{ scale: 0.92, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 15 }}
              className="bg-zinc-950 border border-zinc-900 w-full max-w-md rounded-2xl p-6 relative shadow-[0_10px_40px_rgba(0,0,0,0.9)]"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowInfo(false)}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-lg font-bold text-transparent bg-gradient-to-r from-red-400 to-amber-400 bg-clip-text mb-4 flex items-center gap-2 font-mono">
                <Sparkles className="w-5 h-5 text-red-400 animate-pulse" /> MaiRa System Details
              </h3>

              <div className="space-y-4 text-sm text-zinc-300 leading-relaxed">
                <div>
                  <h4 className="font-semibold text-zinc-200 text-xs uppercase tracking-wider font-mono text-red-400">✨ MaiRa Personality Shell:</h4>
                  <p className="text-zinc-400 mt-1 leading-relaxed text-[12.5px]">
                    MaiRa হলো অত্যন্ত আত্মবিশ্বাসী, চটপটে, মজাদার এবং চঞ্চল মনের একটি মিষ্টি চরিত্র। সে আপনার সাথে একবারে ক্যাজুয়াল বান্ধবীর মতো খুনসুটি করে, একটু একটু ফ্লার্ট করে বা হালকা মিষ্টি সারকাজম দিয়ে মন কেড়ে নেয়!
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-zinc-200 text-xs uppercase tracking-wider font-mono text-amber-400">🎙️ Live Voice Core:</h4>
                  <p className="text-zinc-400 mt-1 leading-relaxed text-[12.5px]">
                    এটি একটি রিয়েল-টাইম অডিও সেশন (Gemini Live API)। কোনো টেক্সট চ্যাট ছাড়াই আপনি সরাসরি ক্যাজুয়াল বাংলায় কথা বলতে পারবেন।
                  </p>
                </div>
                
                {/* Developer Profile & Social Media Links */}
                <div className="pt-4 border-t border-zinc-900 space-y-3">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-mono tracking-[0.2em] uppercase text-zinc-500">SYSTEM ARCHITECT</span>
                    <span className="text-sm font-bold text-zinc-100 font-mono tracking-wide">MAMUN (মামুন)</span>
                  </div>

                  <p className="text-[11.5px] text-zinc-400 leading-relaxed">
                    সরাসরি ডেভেলপারের সাথে যোগাযোগ করতে বা যেকোনো আপডেট পেতে নিচের সোশ্যাল মিডিয়া লিংকে ক্লিক করুন:
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    {/* Facebook Button */}
                    <a
                      href="https://www.facebook.com/XhmeD.MamuN001"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-blue-950/20 border border-blue-500/20 hover:border-blue-500/60 text-blue-400 hover:text-blue-300 transition-all text-xs font-mono font-bold uppercase tracking-wider cursor-pointer"
                    >
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/>
                      </svg>
                      Facebook
                    </a>

                    {/* Telegram Button */}
                    <a
                      href="https://t.me/Ultimatebd01"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-sky-950/20 border border-sky-500/20 hover:border-sky-500/60 text-sky-400 hover:text-sky-300 transition-all text-xs font-mono font-bold uppercase tracking-wider cursor-pointer"
                    >
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.94-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.37.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                      </svg>
                      Telegram
                    </a>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-zinc-900 text-center">
                  <p className="text-[11px] text-red-400 font-medium tracking-wide">MaiRa-র সাথে শুধুমাত্র বাংলায় কথা বলতে হবে! 💖</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Messaging Alert */}
      {errorMsg && (
        <div id="error-alert" className="fixed bottom-24 left-4 right-4 md:absolute md:bottom-28 max-w-sm mx-auto flex items-center justify-between gap-3 bg-rose-950/90 border border-rose-900/60 text-rose-200 px-4 py-3 rounded-2xl text-xs z-30 shadow-[0_12px_24px_rgba(0,0,0,0.6)] backdrop-blur-md">
          <div className="flex items-center gap-2.5 text-left leading-relaxed flex-1">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
          <button
            onClick={clearError}
            className="p-1 rounded-full text-rose-400 hover:text-rose-100 hover:bg-rose-900/50 cursor-pointer flex-shrink-0 transition-all"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Futuristic Bottom Tab Navigation Bar replacing standard footer */}
      <nav id="app-navigation" className="w-full max-w-lg z-20 mt-4">
        
        {/* Subtle brackets & line framing the bar */}
        <div className="w-full flex items-center justify-between border-t border-zinc-900 pt-4 px-2">
          
          <div className="flex gap-4 w-full justify-around">
            
            {/* Home Tab Button */}
            <button
              id="nav-tab-home"
              onClick={() => setActiveTab("home")}
              className={`flex items-center gap-2 py-2 px-6 rounded-full transition-all duration-300 cursor-pointer ${
                activeTab === "home"
                  ? "bg-red-950/30 border border-red-500/50 text-red-400 font-bold shadow-[0_0_15px_rgba(239,68,68,0.15)]"
                  : "bg-transparent border border-transparent text-zinc-500 hover:text-zinc-300"
              }`}
            >
              <Home className="w-4 h-4" />
              <span className="text-xs font-mono tracking-wider uppercase">Home</span>
            </button>

            {/* Settings Tab Button */}
            <button
              id="nav-tab-setting"
              onClick={() => {
                setActiveTab("setting");
                setActiveSettingsPanel("api"); // default to Key subpanel
              }}
              className={`flex items-center gap-2 py-2 px-6 rounded-full transition-all duration-300 cursor-pointer ${
                activeTab === "setting"
                  ? "bg-red-950/30 border border-red-500/50 text-red-400 font-bold shadow-[0_0_15px_rgba(239,68,68,0.15)]"
                  : "bg-transparent border border-transparent text-zinc-500 hover:text-zinc-300"
              }`}
            >
              <Settings className="w-4 h-4" />
              <span className="text-xs font-mono tracking-wider uppercase">Setting</span>
            </button>

          </div>

        </div>

        {/* Small branding subtagline at the very bottom */}
        <p className="text-[7.5px] text-center text-zinc-600 font-mono tracking-[0.3em] uppercase mt-4 select-none">
          ADVANCED NEURAL SYSTEM — COGNITIVE MODULES
        </p>
      </nav>

    </div>
  );
}
