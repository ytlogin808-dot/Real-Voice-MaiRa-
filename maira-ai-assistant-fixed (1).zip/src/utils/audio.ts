/**
 * Conversion and Web Audio utility helpers for raw 16-bit PCM streaming.
 */

export function float32ToInt16(buffer: Float32Array): Int16Array {
  const l = buffer.length;
  const buf = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    const s = Math.max(-1, Math.min(1, buffer[i]));
    buf[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
  }
  return buf;
}

export function base64ToFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const floatBuffer = new Float32Array(bytes.length / 2);
  for (let i = 0; i < floatBuffer.length; i++) {
    const pcm16 = view.getInt16(i * 2, true); // true for little endian
    floatBuffer[i] = pcm16 / 32768;
  }
  return floatBuffer;
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export class AudioPlayer {
  private ctx: AudioContext | null = null;
  private nextStartTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private onPlaybackStateChange?: (isPlaying: boolean) => void;

  constructor(
    private sampleRate: number = 24000,
    onPlaybackStateChange?: (isPlaying: boolean) => void
  ) {
    this.onPlaybackStateChange = onPlaybackStateChange;
  }

  public init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: this.sampleRate,
      });
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public playChunk(base64Data: string) {
    this.init();
    if (!this.ctx) return;

    const floatData = base64ToFloat32(base64Data);
    const audioBuffer = this.ctx.createBuffer(1, floatData.length, this.sampleRate);
    audioBuffer.copyToChannel(floatData, 0);

    const source = this.ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(this.ctx.destination);

    const currentTime = this.ctx.currentTime;
    if (this.nextStartTime < currentTime) {
      this.nextStartTime = currentTime + 0.05; // 50ms buffer to prevent overlap stutter
    }

    source.start(this.nextStartTime);
    
    // Track active sources for stopping
    this.activeSources.push(source);
    
    if (this.onPlaybackStateChange) {
      this.onPlaybackStateChange(true);
    }

    source.onended = () => {
      this.activeSources = this.activeSources.filter((s) => s !== source);
      if (this.activeSources.length === 0 && this.onPlaybackStateChange) {
        this.onPlaybackStateChange(false);
      }
    };

    this.nextStartTime += audioBuffer.duration;
  }

  public stop() {
    this.activeSources.forEach((source) => {
      try {
        source.stop();
      } catch (err) {
        // Node might have already finished
      }
    });
    this.activeSources = [];
    this.nextStartTime = 0;
    if (this.onPlaybackStateChange) {
      this.onPlaybackStateChange(false);
    }
  }

  public close() {
    this.stop();
    if (this.ctx) {
      this.ctx.close();
      this.ctx = null;
    }
  }
}

export class AudioRecorder {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;

  constructor(
    private sampleRate: number = 16000,
    private onAudioChunk: (base64: string) => void
  ) {}

  public async start() {
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: this.sampleRate,
    });

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    this.source = this.ctx.createMediaStreamSource(this.stream);
    this.processor = this.ctx.createScriptProcessor(2048, 1, 1);

    this.processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcm16 = float32ToInt16(inputData);
      const base64 = arrayBufferToBase64(pcm16.buffer);
      this.onAudioChunk(base64);
    };

    this.source.connect(this.processor);
    this.processor.connect(this.ctx.destination);
  }

  public stop() {
    if (this.processor) {
      try {
        this.processor.disconnect();
      } catch (e) {}
      this.processor = null;
    }
    if (this.source) {
      try {
        this.source.disconnect();
      } catch (e) {}
      this.source = null;
    }
    if (this.stream) {
      try {
        this.stream.getTracks().forEach((track) => track.stop());
      } catch (e) {}
      this.stream = null;
    }
    if (this.ctx) {
      try {
        this.ctx.close();
      } catch (e) {}
      this.ctx = null;
    }
  }
}
