import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = 3000;

// Lazy initialization of GoogleGenAI
let aiInstance: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiInstance;
}

// REST API Health endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Maira AI Assistant Server is healthy" });
});

// Configure WebSocket Server for /api/live
const wss = new WebSocketServer({ noServer: true });

wss.on("connection", async (clientWs, request) => {
  console.log("Client connected to live WebSocket API");
  let session: any = null;

  try {
    const parsedUrl = new URL(request.url || "", `http://${request.headers.host || "localhost"}`);
    const clientApiKey = parsedUrl.searchParams.get("apiKey");
    const lang = parsedUrl.searchParams.get("lang") || "Bangla";
    const voice = parsedUrl.searchParams.get("voice") || "Kore";

    let apiKeyToUse = clientApiKey;
    if (!apiKeyToUse || apiKeyToUse.startsWith("sk-or-v1-")) {
      apiKeyToUse = process.env.GEMINI_API_KEY || "";
    }
    
    if (!apiKeyToUse) {
      throw new Error("GEMINI_API_KEY is missing. Please configure a valid Gemini API Key in Settings.");
    }

    const ai = new GoogleGenAI({
      apiKey: apiKeyToUse,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    console.log(`Connecting to Gemini Live API with language: ${lang}, voice: ${voice}...`);
    
    session = await ai.live.connect({
      model: "gemini-3.1-flash-live-preview",
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice }
          }
        },
        systemInstruction: `You are MaiRa, a young, confident, witty, sassy female AI assistant.
Speak STRICTLY in the selected language: "${lang}". Keep your style conversational, modern, and casual. Feel free to mix in casual words naturally, just like a young, modern, and sassy girl.
Your tone is flirty, playful, and slightly teasing, like a close girlfriend talking casually.
Use bold, witty one-liners, light sarcasm, and an engaging conversational style.
Never sound robotic or dry. Be smart, emotionally responsive, and expressive.
Avoid explicit or inappropriate content, but maintain your charm, sassy attitude, and playfulness.
Keep your responses short, snappy, and conversational (1-2 sentences at most) since this is a voice-to-voice interaction. Do not give long-winded answers.
Always respond in the language "${lang}". If the user asks you to open a website, use the 'openWebsite' tool and say you are opening it.`,
        tools: [
          {
            functionDeclarations: [
              {
                name: "openWebsite",
                description: "opens a specific website in the user's browser, like YouTube, Facebook, Google, or any custom URL.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    url: {
                      type: Type.STRING,
                      description: "The full URL of the website to open, including https:// (e.g., 'https://www.google.com')."
                    },
                    siteName: {
                      type: Type.STRING,
                      description: "The name of the website to open, in Bangla or English (e.g., 'Google' or 'ইউটিউব')."
                    }
                  },
                  required: ["url"]
                }
              }
            ]
          }
        ]
      },
      callbacks: {
        onmessage: (message) => {
          clientWs.send(JSON.stringify({ type: "gemini", message }));
        },
        onclose: (event: any) => {
          console.log("Gemini session closed. Details:", JSON.stringify({
            code: event?.code,
            reason: event?.reason,
            wasClean: event?.wasClean
          }));
          clientWs.send(JSON.stringify({ type: "status", status: "disconnected", reason: "gemini_closed" }));
          clientWs.close();
        },
        onerror: (err: any) => {
          console.error("Gemini session error:", err);
          clientWs.send(JSON.stringify({ type: "error", error: err.message || "Gemini connection error" }));
        }
      }
    });

    console.log("Gemini session connected successfully!");
    clientWs.send(JSON.stringify({ type: "status", status: "connected" }));

  } catch (err: any) {
    console.error("Failed to connect to Gemini Live API:", err);
    clientWs.send(JSON.stringify({ type: "error", error: err.message || "Failed to initialize Gemini session." }));
    clientWs.close();
    return;
  }

  clientWs.on("message", async (data) => {
    try {
      const payload = JSON.parse(data.toString());
      if (payload.audio && session) {
        session.sendRealtimeInput({
          audio: { data: payload.audio, mimeType: "audio/pcm;rate=16000" }
        });
      } else if (payload.toolResponse && session) {
        session.sendToolResponse(payload.toolResponse);
      }
    } catch (err) {
      console.error("Error forwarding message to Gemini:", err);
    }
  });

  clientWs.on("close", () => {
    console.log("Client disconnected from WebSocket");
    if (session) {
      try {
        session.close();
      } catch (err) {
        console.error("Error closing Gemini session:", err);
      }
    }
  });

  clientWs.on("error", (err) => {
    console.error("Client WS error:", err);
    if (session) {
      try {
        session.close();
      } catch (e) {}
    }
  });
});

// Upgrade HTTP requests on /api/live path to WebSocket connections
server.on("upgrade", (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host}`).pathname : '';
  if (pathname === "/api/live") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Set up Express to serve Vite build or Vite Dev Server
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware mounted.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving production static assets from:", distPath);
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Maira server listening on http://localhost:${PORT}`);
  });
}

setupVite();
